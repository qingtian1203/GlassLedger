package com.kath.glassledger;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    static class Tx {
        double amount;
        String note;
        boolean income;
        Tx(double amount, String note, boolean income) {
            this.amount = amount;
            this.note = note;
            this.income = income;
        }
    }

    private final ArrayList<Tx> transactions = new ArrayList<>();
    private android.content.SharedPreferences prefs;
    private TextView balance, incomeText, expenseText;
    private LinearLayout list;
    private EditText amount, note;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("glassledger", MODE_PRIVATE);
        balance = findViewById(R.id.tvBalance);
        incomeText = findViewById(R.id.tvIncome);
        expenseText = findViewById(R.id.tvExpense);
        list = findViewById(R.id.transactionContainer);
        amount = findViewById(R.id.etAmount);
        note = findViewById(R.id.etNote);

        load();
        refresh();

        findViewById(R.id.btnExpense).setOnClickListener(v -> add(false));
        findViewById(R.id.btnIncome).setOnClickListener(v -> add(true));
        findViewById(R.id.btnClear).setOnClickListener(v -> clearAll());
    }

    private void add(boolean isIncome) {
        Double value = parseAmount();
        if (value == null || value <= 0) {
            amount.setError("Enter a valid amount");
            return;
        }

        String text = note.getText().toString().trim();
        if (text.isEmpty()) text = isIncome ? "Income" : "Expense";

        transactions.add(new Tx(value, text, isIncome));
        save();
        amount.setText("");
        note.setText("");
        refresh();
    }

    private Double parseAmount() {
        try { return Double.parseDouble(amount.getText().toString().trim()); }
        catch (Exception e) { return null; }
    }

    private String money(double value) {
        return String.format(Locale.US, "₱%,.2f", value);
    }

    private void refresh() {
        double in = 0, out = 0;
        for (Tx tx : transactions) {
            if (tx.income) in += tx.amount;
            else out += tx.amount;
        }

        balance.setText(money(in - out));
        incomeText.setText("Income: " + money(in));
        expenseText.setText("Expenses: " + money(out));
        list.removeAllViews();

        if (transactions.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No transactions yet.");
            empty.setTextSize(16);
            empty.setTextColor(Color.DKGRAY);
            empty.setPadding(12, 20, 12, 20);
            list.addView(empty);
            return;
        }

        for (int i = transactions.size() - 1; i >= 0; i--) {
            final int index = i;
            Tx tx = transactions.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(8, 10, 8, 10);

            TextView text = new TextView(this);
            text.setText(tx.note + "\n" + (tx.income ? "+" : "-") + money(tx.amount));
            text.setTextSize(16);
            text.setTextColor(tx.income ? Color.rgb(46,125,50) : Color.rgb(198,40,40));
            text.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));

            Button delete = new Button(this);
            delete.setText("Delete");
            delete.setOnClickListener(v -> {
                transactions.remove(index);
                save();
                refresh();
            });

            row.addView(text);
            row.addView(delete);
            list.addView(row);
        }
    }

    private void save() {
        JSONArray a = new JSONArray();
        for (Tx tx : transactions) {
            JSONObject o = new JSONObject();
            try {
                o.put("amount", tx.amount);
                o.put("note", tx.note);
                o.put("income", tx.income);
                a.put(o);
            } catch (Exception ignored) {}
        }
        prefs.edit().putString("transactions", a.toString()).apply();
    }

    private void load() {
        String raw = prefs.getString("transactions", "");
        if (raw.isEmpty()) return;
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                transactions.add(new Tx(
                    o.getDouble("amount"),
                    o.getString("note"),
                    o.getBoolean("income")
                ));
            }
        } catch (Exception ignored) {}
    }

    private void clearAll() {
        if (transactions.isEmpty()) return;
        new AlertDialog.Builder(this)
            .setTitle("Clear all?")
            .setMessage("All saved transactions will be deleted.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear", (d, w) -> {
                transactions.clear();
                save();
                refresh();
            }).show();
    }
}
