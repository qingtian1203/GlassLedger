plugins {
    id("com.android.application")
}

android {
    namespace = "com.kath.glassledger"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kath.glassledger"
        minSdk = 24
        targetSdk = 35
        versionCode = 6
        versionName = "1.0.6"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
