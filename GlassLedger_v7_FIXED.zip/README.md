# GlassLedger v6

Android bookkeeping app.

This version intentionally uses **Java instead of Kotlin**, so the previous
`compileReleaseKotlin` / Kotlin source errors cannot occur.

Features:
- Income
- Expenses
- Balance
- Notes
- Delete transaction
- Clear all
- Local storage

Build:
GitHub → Actions → Build GlassLedger APK → Run workflow.
Download the `GlassLedger-APK` artifact when complete.
