# GlassLedger

A simple Android bookkeeping app.

## Features
- Add income
- Add expenses
- See balance, total income and total expenses
- Add notes to transactions
- Delete individual transactions
- Clear all transactions
- Data is saved locally on the phone

## Build
The GitHub Actions workflow builds an installable debug APK.

Go to:
Actions → Build GlassLedger APK → Run workflow

After it finishes:
Artifacts → GlassLedger-APK
