package com.kath.glassledger

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {

    private data class Transaction(
        val amount: Double,
        val note: String,
        val type: String
    )

    private val transactions = mutableListOf<Transaction>()
    private val prefs by lazy { getSharedPreferences("glassledger", MODE_PRIVATE) }

    private lateinit var tvBalance: TextView
    private lateinit var tvIncome: TextView
    private lateinit var tvExpense: TextView
    private lateinit var container: LinearLayout
    private lateinit var amountInput: EditText
    private lateinit var noteInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvBalance = findViewById(R.id.tvBalance)
        tvIncome = findViewById(R.id.tvIncome)
        tvExpense = findViewById(R.id.tvExpense)
        container = findViewById(R.id.transactionContainer)
        amountInput = findViewById(R.id.etAmount)
        noteInput = findViewById(R.id.etNote)

        loadTransactions()
        refresh()

        findViewById<Button>(R.id.btnExpense).setOnClickListener {
            addTransaction("expense")
        }

        findViewById<Button>(R.id.btnIncome).setOnClickListener {
            addTransaction("income")
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            if (transactions.isEmpty()) return@setOnClickListener
            AlertDialog.Builder(this)
                .setTitle("Clear all?")
                .setMessage("All saved transactions will be deleted.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    transactions.clear()
                    saveTransactions()
                    refresh()
                }
                .show()
        }
    }

    private fun addTransaction(type: String) {
        val amount = amountInput.text.toString().toDoubleOrNull()
        if (amount == null || amount <= 0) {
            amountInput.error = "Enter a valid amount"
            return
        }

        val note = noteInput.text.toString().trim().ifEmpty {
            if (type == "income") "Income" else "Expense"
        }

        transactions.add(Transaction(amount, note, type))
        saveTransactions()
        amountInput.text.clear()
        noteInput.text.clear()
        refresh()
    }

    private fun refresh() {
        var income = 0.0
        var expense = 0.0

        transactions.forEach {
            if (it.type == "income") income += it.amount else expense += it.amount
        }

        val balance = income - expense

        tvBalance.text = money(balance)
        tvIncome.text = "Income: ${money(income)}"
        tvExpense.text = "Expenses: ${money(expense)}"

        container.removeAllViews()

        if (transactions.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No transactions yet."
                textSize = 16f
                setTextColor(Color.DKGRAY)
                setPadding(12, 20, 12, 20)
            }
            container.addView(empty)
            return
        }

        transactions.asReversed().forEachIndexed { reversedIndex, transaction ->
            val originalIndex = transactions.lastIndex - reversedIndex
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 14, 12, 14)
                setBackgroundColor(Color.WHITE)
            }

            val text = TextView(this).apply {
                text = "${transaction.note}\n${if (transaction.type == "income") "+" else "-"}${money(transaction.amount)}"
                textSize = 16f
                setTextColor(
                    if (transaction.type == "income") Color.rgb(46, 125, 50)
                    else Color.rgb(198, 40, 40)
                )
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }

            val delete = Button(this).apply {
                text = "Delete"
                setOnClickListener {
                    transactions.removeAt(originalIndex)
                    saveTransactions()
                    refresh()
                }
            }

            row.addView(text)
            row.addView(delete)
            container.addView(row)

            val divider = Space(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    -1, 1
                )
                setBackgroundColor(Color.LTGRAY)
            }
            container.addView(divider)
        }
    }

    private fun money(value: Double): String =
        String.format(Locale.US, "₱%,.2f", value)

    private fun saveTransactions() {
        val array = JSONArray()
        transactions.forEach {
            array.put(JSONObject().apply {
                put("amount", it.amount)
                put("note", it.note)
                put("type", it.type)
            })
        }
        prefs.edit().putString("transactions", array.toString()).apply()
    }

    private fun loadTransactions() {
        transactions.clear()
        val raw = prefs.getString("transactions", null) ?: return
        runCatching {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                transactions.add(
                    Transaction(
                        item.getDouble("amount"),
                        item.getString("note"),
                        item.getString("type")
                    )
                )
            }
        }
    }
}
