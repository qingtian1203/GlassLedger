package com.kath.glassledger

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private data class Transaction(
    val id: Long,
    val amount: Double,
    val income: Boolean,
    val category: String,
    val note: String,
    val date: Long
)

private class Store(context: Context) {
    private val prefs = context.getSharedPreferences("ledger", Context.MODE_PRIVATE)

    fun load(): List<Transaction> = runCatching {
        val array = JSONArray(prefs.getString("items", "[]"))
        buildList {
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                add(
                    Transaction(
                        id = obj.getLong("id"),
                        amount = obj.getDouble("amount"),
                        income = obj.getBoolean("income"),
                        category = obj.getString("category"),
                        note = obj.getString("note"),
                        date = obj.getLong("date")
                    )
                )
            }
        }.sortedByDescending { it.date }
    }.getOrDefault(emptyList())

    fun save(items: List<Transaction>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("amount", item.amount)
                    put("income", item.income)
                    put("category", item.category)
                    put("note", item.note)
                    put("date", item.date)
                }
            )
        }
        prefs.edit().putString("items", array.toString()).apply()
    }
}

private val Background = Color(0xFF07101D)
private val Glass = Color(0x28FFFFFF)
private val TextPrimary = Color(0xFFF4F7FB)
private val TextMuted = Color(0xFFAAB7C8)
private val Accent = Color(0xFF8BE9FF)
private val IncomeColor = Color(0xFF8EF0C4)
private val ExpenseColor = Color(0xFFFFA7B8)

private fun money(value: Double): String =
    String.format(Locale.getDefault(), "%,.2f", value)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GlassLedgerApp(Store(this)) }
    }
}

@Composable
private fun GlassLedgerApp(store: Store) {
    var transactions by remember { mutableStateOf(store.load()) }
    var showAddDialog by remember { mutableStateOf(false) }

    val now = Calendar.getInstance()
    val monthTransactions = transactions.filter { transaction ->
        Calendar.getInstance().apply { timeInMillis = transaction.date }.let { calendar ->
            calendar.get(Calendar.MONTH) == now.get(Calendar.MONTH) &&
                calendar.get(Calendar.YEAR) == now.get(Calendar.YEAR)
        }
    }

    val income = monthTransactions.filter { it.income }.sumOf { it.amount }
    val expense = monthTransactions.filter { !it.income }.sumOf { it.amount }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Background,
            primary = Accent,
            onBackground = TextPrimary
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF10283D), Background, Color(0xFF091523))
                    )
                )
        ) {
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .offset(x = 190.dp, y = 40.dp)
                    .background(Color(0x228BE9FF), CircleShape)
                    .blur(70.dp)
            )

            Scaffold(
                containerColor = Color.Transparent,
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = { showAddDialog = true },
                        containerColor = Accent,
                        contentColor = Background
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "添加")
                    }
                }
            ) { padding ->
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = 18.dp,
                        top = padding.calculateTopPadding() + 22.dp,
                        end = 18.dp,
                        bottom = 110.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Text("GlassLedger", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text(
                            SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date()),
                            color = TextMuted
                        )
                    }

                    item {
                        GlassCard {
                            Text("本月结余", color = TextMuted, fontSize = 13.sp)
                            Text(
                                "₱${money(income - expense)}",
                                fontSize = 34.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard("收入", income, IncomeColor, Modifier.weight(1f))
                                StatCard("支出", expense, ExpenseColor, Modifier.weight(1f))
                            }
                        }
                    }

                    item {
                        Text("最近记录", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    }

                    if (transactions.isEmpty()) {
                        item {
                            GlassCard {
                                Text("还没有记账记录")
                                Text("点击右下角 ＋ 开始记录", color = TextMuted, fontSize = 13.sp)
                            }
                        }
                    }

                    items(transactions.take(30), key = { it.id }) { transaction ->
                        var confirmDelete by remember { mutableStateOf(false) }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { confirmDelete = true },
                            shape = RoundedCornerShape(22.dp),
                            color = Glass
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.08f)) {
                                    Icon(
                                        Icons.Default.ReceiptLong,
                                        contentDescription = null,
                                        modifier = Modifier.padding(10.dp),
                                        tint = Accent
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(transaction.category, fontWeight = FontWeight.SemiBold)
                                    if (transaction.note.isNotBlank()) {
                                        Text(transaction.note, color = TextMuted, fontSize = 12.sp)
                                    }
                                    Text(
                                        SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
                                            .format(Date(transaction.date)),
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )
                                }
                                Text(
                                    text = (if (transaction.income) "+" else "-") +
                                        "₱" + money(transaction.amount),
                                    color = if (transaction.income) IncomeColor else ExpenseColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (confirmDelete) {
                            AlertDialog(
                                onDismissRequest = { confirmDelete = false },
                                title = { Text("删除这笔记录？") },
                                text = { Text("删除后无法恢复。") },
                                confirmButton = {
                                    TextButton(
                                        onClick = {
                                            confirmDelete = false
                                            transactions = transactions.filterNot { it.id == transaction.id }
                                            store.save(transactions)
                                        }
                                    ) { Text("删除") }
                                },
                                dismissButton = {
                                    TextButton(onClick = { confirmDelete = false }) { Text("取消") }
                                }
                            )
                        }
                    }
                }
            }

            if (showAddDialog) {
                AddTransactionDialog(
                    onClose = { showAddDialog = false },
                    onSave = { transaction ->
                        transactions = listOf(transaction) + transactions
                        store.save(transactions)
                        showAddDialog = false
                    }
                )
            }
        }
    }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        color = Glass
    ) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

@Composable
private fun StatCard(label: String, value: Double, color: Color, modifier: Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.07f)
    ) {
        Column(Modifier.padding(13.dp)) {
            Text(label, color = TextMuted, fontSize = 12.sp)
            Text("₱${money(value)}", color = color, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun AddTransactionDialog(
    onClose: () -> Unit,
    onSave: (Transaction) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var income by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf("餐饮") }
    var note by remember { mutableStateOf("") }
    var categoryMenuOpen by remember { mutableStateOf(false) }

    val categories = if (income) {
        listOf("工资", "Freelance", "红包", "其他")
    } else {
        listOf("餐饮", "日用品", "交通", "住房", "购物", "医疗", "娱乐", "旅行", "数码", "其他")
    }

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF142334),
        title = { Text("记一笔", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !income,
                        onClick = {
                            income = false
                            category = "餐饮"
                        },
                        label = { Text("支出") }
                    )
                    FilterChip(
                        selected = income,
                        onClick = {
                            income = true
                            category = "工资"
                        },
                        label = { Text("收入") }
                    )
                }

                OutlinedTextField(
                    value = amount,
                    onValueChange = { value ->
                        amount = value.filter { character ->
                            character.isDigit() || character == '.'
                        }
                    },
                    label = { Text("金额") },
                    prefix = { Text("₱ ") },
                    singleLine = true
                )

                ExposedDropdownMenuBox(
                    expanded = categoryMenuOpen,
                    onExpandedChange = { categoryMenuOpen = !categoryMenuOpen }
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("分类") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryMenuOpen)
                        },
                        modifier = Modifier.menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = categoryMenuOpen,
                        onDismissRequest = { categoryMenuOpen = false }
                    ) {
                        categories.forEach { item ->
                            DropdownMenuItem(
                                text = { Text(item) },
                                onClick = {
                                    category = item
                                    categoryMenuOpen = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("备注（可选）") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            val parsedAmount = amount.toDoubleOrNull() ?: 0.0
            TextButton(
                enabled = parsedAmount > 0.0,
                onClick = {
                    val now = System.currentTimeMillis()
                    onSave(
                        Transaction(
                            id = now,
                            amount = parsedAmount,
                            income = income,
                            category = category,
                            note = note,
                            date = now
                        )
                    )
                }
            ) { Text("保存") }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text("取消") }
        }
    )
}
