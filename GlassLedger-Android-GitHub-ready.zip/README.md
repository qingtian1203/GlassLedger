# GlassLedger
A privacy-first Android bookkeeping app with a Liquid Glass inspired UI.
Local-only storage, income/expense categories, notes, monthly summary and deletion.
Build with JDK 17, Gradle 8.9 and Android SDK 35.
