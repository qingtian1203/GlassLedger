package com.kath.glassledger

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Transaction(val id: Long, val amount: Double, val income: Boolean, val category: String, val note: String, val date: Long)

class Store(context: Context) {
    private val p = context.getSharedPreferences("ledger", Context.MODE_PRIVATE)
    fun load(): List<Transaction> = runCatching {
        val a = JSONArray(p.getString("items","[]"))
        List(a.length()) { i -> a.getJSONObject(i).let { o ->
            Transaction(o.getLong("id"),o.getDouble("amount"),o.getBoolean("income"),o.getString("category"),o.getString("note"),o.getLong("date"))
        }}.sortedByDescending { it.date }
    }.getOrDefault(emptyList())
    fun save(items: List<Transaction>) {
        val a=JSONArray()
        items.forEach { t -> a.put(JSONObject().apply {
            put("id",t.id); put("amount",t.amount); put("income",t.income); put("category",t.category); put("note",t.note); put("date",t.date)
        })}
        p.edit().putString("items",a.toString()).apply()
    }
}

private val BG=Color(0xFF07101D)
private val GLASS=Color(0x28FFFFFF)
private val TEXT=Color(0xFFF4F7FB)
private val MUTED=Color(0xFFAAB7C8)
private val ACCENT=Color(0xFF8BE9FF)
private val GREEN=Color(0xFF8EF0C4)
private val RED=Color(0xFFFFA7B8)

class MainActivity: ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { App(Store(this)) } }
}

@Composable
fun App(store: Store) {
    var list by remember { mutableStateOf(store.load()) }
    var add by remember { mutableStateOf(false) }
    val now=Calendar.getInstance()
    val month=list.filter { Calendar.getInstance().apply { timeInMillis=it.date }.let { c -> c.get(Calendar.MONTH)==now.get(Calendar.MONTH) && c.get(Calendar.YEAR)==now.get(Calendar.YEAR) } }
    val inc=month.filter{it.income}.sumOf{it.amount}; val exp=month.filter{!it.income}.sumOf{it.amount}
    MaterialTheme(colorScheme=darkColorScheme(background=BG,primary=ACCENT,onBackground=TEXT)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10283D),BG,Color(0xFF091523))))) {
            Box(Modifier.size(220.dp).offset(190.dp,40.dp).background(Color(0x228BE9FF),CircleShape).blur(70.dp))
            Scaffold(containerColor=Color.Transparent,floatingActionButton={
                FloatingActionButton(onClick={add=true},containerColor=ACCENT,contentColor=BG){Icon(Icons.Default.Add,"添加")}
            }) { pad ->
                LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(18.dp, pad.calculateTopPadding()+22.dp,18.dp,110.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
                    item { Text("GlassLedger",fontSize=30.sp,fontWeight=FontWeight.Bold); Text(SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(Date()),color=MUTED) }
                    item { CardBox {
                        Text("本月结余",color=MUTED,fontSize=13.sp)
                        Text("₱${"%,.2f".format(inc-exp)}",fontSize=34.sp,fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            Stat("收入",inc,GREEN,Modifier.weight(1f)); Stat("支出",exp,RED,Modifier.weight(1f))
                        }
                    }}
                    item { Text("最近记录",fontSize=18.sp,fontWeight=FontWeight.SemiBold) }
                    if(list.isEmpty()) item { CardBox { Text("还没有记账记录"); Text("点击右下角 ＋ 开始记录",color=MUTED,fontSize=13.sp) } }
                    items(list.take(30),key={it.id}) { t ->
                        var confirm by remember{mutableStateOf(false)}
                        Surface(Modifier.fillMaxWidth().clickable{confirm=true},shape=RoundedCornerShape(22.dp),color=GLASS) {
                            Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                                Surface(shape=CircleShape,color=Color.White.copy(alpha=.08f)){Icon(Icons.Default.ReceiptLong,null,Modifier.padding(10.dp),tint=ACCENT)}
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)){Text(t.category,fontWeight=FontWeight.SemiBold); if(t.note.isNotBlank())Text(t.note,color=MUTED,fontSize=12.sp); Text(SimpleDateFormat("MMM d, HH:mm",Locale.getDefault()).format(Date(t.date)),color=MUTED,fontSize=11.sp)}
                                Text((if(t.income) "+" else "-")+"₱${"%,.2f".format(t.amount)},color=if(t.income)GREEN else RED,fontWeight=FontWeight.Bold)
                            }
                        }
                        if(confirm) AlertDialog(onDismissRequest={confirm=false},title={Text("删除这笔记录？")},text={Text("删除后无法恢复。")},confirmButton={TextButton(onClick={confirm=false;list=list.filterNot{it.id==t.id};store.save(list)}){Text("删除")}},dismissButton={TextButton(onClick={confirm=false}){Text("取消")}})
                    }
                }
            }
        }
        if(add) AddDialog({add=false}) { t -> list=listOf(t)+list;store.save(list);add=false }
    }
}

@Composable fun CardBox(content:@Composable ColumnScope.()->Unit)=Surface(Modifier.fillMaxWidth(),shape=RoundedCornerShape(26.dp),color=GLASS){Column(Modifier.padding(18.dp),content=content)}
@Composable fun Stat(label:String,value:Double,color:Color,mod:Modifier)=Surface(mod,shape=RoundedCornerShape(18.dp),color=Color.White.copy(alpha=.07f)){Column(Modifier.padding(13.dp)){Text(label,color=MUTED,fontSize=12.sp);Text("₱${"%,.2f".format(value)}",color=color,fontWeight=FontWeight.SemiBold)}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddDialog(close:()->Unit,save:(Transaction)->Unit) {
    var amount by remember{mutableStateOf("")}; var income by remember{mutableStateOf(false)}; var cat by remember{mutableStateOf("餐饮")}; var note by remember{mutableStateOf("")}; var open by remember{mutableStateOf(false)}
    val cats=if(income) listOf("工资","Freelance","红包","其他") else listOf("餐饮","日用品","交通","住房","购物","医疗","娱乐","旅行","数码","其他")
    AlertDialog(onDismissRequest=close,containerColor=Color(0xFF142334),title={Text("记一笔",fontWeight=FontWeight.Bold)},text={
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(!income,{income=false;cat="餐饮"},{Text("支出")});FilterChip(income,{income=true;cat="工资"},{Text("收入")})}
            OutlinedTextField(amount,{amount=it.filter{c->c.isDigit()||c=='.'}},label={Text("金额")},prefix={Text("₱ ")},singleLine=true)
            ExposedDropdownMenuBox(expanded=open,onExpandedChange={open=!open}) {
                OutlinedTextField(cat,{},readOnly=true,label={Text("分类")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(open)},modifier=Modifier.menuAnchor())
                ExposedDropdownMenu(open,{open=false}){cats.forEach{DropdownMenuItem(text={Text(it)},onClick={cat=it;open=false})}}
            }
            OutlinedTextField(note,{note=it},label={Text("备注（可选）")},singleLine=true)
        }
    },confirmButton={TextButton(enabled=(amount.toDoubleOrNull()?:0.0)>0,onClick={save(Transaction(System.currentTimeMillis(),amount.toDouble(),income,cat,note,System.currentTimeMillis()))}){Text("保存")}},dismissButton={TextButton(onClick=close){Text("取消")}})
}
